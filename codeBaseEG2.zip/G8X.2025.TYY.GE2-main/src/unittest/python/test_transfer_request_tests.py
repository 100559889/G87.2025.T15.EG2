"""class for testing the regsiter_order method"""
import unittest
from uc3m_money import AccountManager

class MyTestCase(unittest.TestCase):
    """class for testing the register_order method"""
    def test_something( self ):
        """dummy test"""
        self.assertEqual(True, False)


if __name__ == '__main__':
    unittest.main()
